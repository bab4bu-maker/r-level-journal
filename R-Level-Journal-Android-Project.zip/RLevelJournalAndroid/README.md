# R-Level Journal Android

Aplikasi jurnal compounding fixed-lot, offline, berbasis WebView.

## Build
JDK 17 + Android SDK 34:

```bash
gradle :app:assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

GitHub Actions juga tersedia di `.github/workflows/build-apk.yml`.
