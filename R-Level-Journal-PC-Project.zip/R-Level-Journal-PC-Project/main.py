import csv
import json
import os
import shutil
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime

APP_NAME = "R-Level Journal"

LEVELS = [
    {"level": 1, "lot": 0.01, "modal": 25,   "r": 5,   "profit_target": 30,   "total": 55},
    {"level": 2, "lot": 0.02, "modal": 55,   "r": 10,  "profit_target": 60,   "total": 115},
    {"level": 3, "lot": 0.04, "modal": 115,  "r": 20,  "profit_target": 120,  "total": 235},
    {"level": 4, "lot": 0.08, "modal": 235,  "r": 40,  "profit_target": 240,  "total": 475},
    {"level": 5, "lot": 0.16, "modal": 475,  "r": 80,  "profit_target": 480,  "total": 955},
    {"level": 6, "lot": 0.32, "modal": 955,  "r": 160, "profit_target": 960,  "total": 1915},
    {"level": 7, "lot": 0.64, "modal": 1915, "r": 320, "profit_target": 1920, "total": 3835},
    {"level": 8, "lot": 1.28, "modal": 3835, "r": 640, "profit_target": 3840, "total": 7675},
]

def data_dir():
    root = os.getenv("APPDATA") or os.path.expanduser("~")
    path = os.path.join(root, "RLevelJournal")
    os.makedirs(path, exist_ok=True)
    return path

DATA_FILE = os.path.join(data_dir(), "data.json")

DEFAULT_DATA = {
    "balance": 25.0,
    "current_level": 1,
    "trades": [],
    "auto_up": True
}

def money(v):
    if abs(v - round(v)) < 1e-9:
        return f"${int(round(v)):,}".replace(",", ".")
    return f"${v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

def lot_text(v):
    return f"{v:.2f}".replace(".", ",")

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1050x700")
        self.minsize(920, 620)
        self.configure(bg="#111827")
        self.data = self.load_data()

        self.style = ttk.Style(self)
        try:
            self.style.theme_use("clam")
        except:
            pass

        self.style.configure("TFrame", background="#111827")
        self.style.configure("Card.TFrame", background="#1f2937")
        self.style.configure("TLabel", background="#111827", foreground="#f9fafb", font=("Segoe UI", 10))
        self.style.configure("Card.TLabel", background="#1f2937", foreground="#f9fafb", font=("Segoe UI", 10))
        self.style.configure("Big.TLabel", background="#1f2937", foreground="#ffffff", font=("Segoe UI Semibold", 22))
        self.style.configure("Title.TLabel", background="#111827", foreground="#ffffff", font=("Segoe UI Semibold", 22))
        self.style.configure("Sub.TLabel", background="#111827", foreground="#9ca3af", font=("Segoe UI", 10))
        self.style.configure("TButton", font=("Segoe UI Semibold", 10), padding=8)
        self.style.configure("Treeview", rowheight=30, font=("Segoe UI", 10), background="#111827", fieldbackground="#111827", foreground="#f9fafb")
        self.style.configure("Treeview.Heading", font=("Segoe UI Semibold", 10))
        self.style.configure("TNotebook", background="#111827", borderwidth=0)
        self.style.configure("TNotebook.Tab", font=("Segoe UI Semibold", 10), padding=(18, 10))
        self.style.configure("Horizontal.TProgressbar", thickness=16)

        self.build_ui()
        self.refresh_all()

    def load_data(self):
        try:
            if os.path.exists(DATA_FILE):
                with open(DATA_FILE, "r", encoding="utf-8") as f:
                    d = json.load(f)
                for k, v in DEFAULT_DATA.items():
                    d.setdefault(k, v)
                return d
        except Exception:
            pass
        return DEFAULT_DATA.copy()

    def save_data(self):
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)

    def build_ui(self):
        header = ttk.Frame(self)
        header.pack(fill="x", padx=22, pady=(18, 10))
        ttk.Label(header, text="R-Level Journal", style="Title.TLabel").pack(side="left")
        ttk.Label(header, text="PC • Fixed Level Compounding", style="Sub.TLabel").pack(side="left", padx=(12, 0), pady=(8, 0))

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=20, pady=(0, 18))

        self.tab_dash = ttk.Frame(self.notebook)
        self.tab_journal = ttk.Frame(self.notebook)
        self.tab_levels = ttk.Frame(self.notebook)
        self.tab_settings = ttk.Frame(self.notebook)

        self.notebook.add(self.tab_dash, text="Dashboard")
        self.notebook.add(self.tab_journal, text="Jurnal")
        self.notebook.add(self.tab_levels, text="Level 1–8")
        self.notebook.add(self.tab_settings, text="Pengaturan")

        self.build_dashboard()
        self.build_journal()
        self.build_levels()
        self.build_settings()

    def card(self, parent, title, var, col):
        f = ttk.Frame(parent, style="Card.TFrame", padding=18)
        f.grid(row=0, column=col, sticky="nsew", padx=6)
        ttk.Label(f, text=title, style="Card.TLabel").pack(anchor="w")
        ttk.Label(f, textvariable=var, style="Big.TLabel").pack(anchor="w", pady=(7, 0))
        return f

    def build_dashboard(self):
        for i in range(5):
            self.tab_dash.columnconfigure(i, weight=1)

        self.v_balance = tk.StringVar()
        self.v_level = tk.StringVar()
        self.v_lot = tk.StringVar()
        self.v_r = tk.StringVar()
        self.v_target = tk.StringVar()
        self.v_progress = tk.StringVar()

        cards = ttk.Frame(self.tab_dash)
        cards.pack(fill="x", padx=8, pady=(16, 12))
        for i in range(5):
            cards.columnconfigure(i, weight=1)

        self.card(cards, "Balance", self.v_balance, 0)
        self.card(cards, "Level", self.v_level, 1)
        self.card(cards, "Lot", self.v_lot, 2)
        self.card(cards, "1R", self.v_r, 3)
        self.card(cards, "Target", self.v_target, 4)

        quick = ttk.Frame(self.tab_dash, style="Card.TFrame", padding=20)
        quick.pack(fill="x", padx=14, pady=8)
        ttk.Label(quick, text="Quick Trade", style="Card.TLabel", font=("Segoe UI Semibold", 14)).pack(anchor="w")
        row = ttk.Frame(quick, style="Card.TFrame")
        row.pack(fill="x", pady=(14, 6))
        ttk.Button(row, text="WIN  +3R", command=lambda: self.add_trade(3.0, "WIN +3R")).pack(side="left", padx=(0, 10))
        ttk.Button(row, text="LOSE  -1R", command=lambda: self.add_trade(-1.0, "LOSE -1R")).pack(side="left", padx=(0, 10))
        ttk.Button(row, text="Buka Jurnal", command=lambda: self.notebook.select(self.tab_journal)).pack(side="left")

        prog = ttk.Frame(self.tab_dash, style="Card.TFrame", padding=20)
        prog.pack(fill="x", padx=14, pady=8)
        ttk.Label(prog, text="Progress ke level berikutnya", style="Card.TLabel", font=("Segoe UI Semibold", 13)).pack(anchor="w")
        self.progress = ttk.Progressbar(prog, mode="determinate", maximum=100)
        self.progress.pack(fill="x", pady=(14, 8))
        ttk.Label(prog, textvariable=self.v_progress, style="Card.TLabel").pack(anchor="w")

        note = ttk.Frame(self.tab_dash, style="Card.TFrame", padding=20)
        note.pack(fill="both", expand=True, padx=14, pady=8)
        ttk.Label(note, text="Aturan level", style="Card.TLabel", font=("Segoe UI Semibold", 13)).pack(anchor="w")
        ttk.Label(
            note,
            text="Naik level otomatis saat balance mencapai modal level berikutnya. "
                 "Turun level dibuat manual supaya satu kali loss tidak langsung menurunkan level.",
            style="Card.TLabel",
            wraplength=850,
            justify="left"
        ).pack(anchor="w", pady=(8, 0))

    def build_journal(self):
        top = ttk.Frame(self.tab_journal, style="Card.TFrame", padding=16)
        top.pack(fill="x", padx=14, pady=(16, 8))

        ttk.Label(top, text="Tanggal", style="Card.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 8))
        self.date_var = tk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))
        ttk.Entry(top, textvariable=self.date_var, width=14).grid(row=1, column=0, padx=(0, 14), pady=(4, 0))

        ttk.Label(top, text="Hasil (R)", style="Card.TLabel").grid(row=0, column=1, sticky="w", padx=(0, 8))
        self.r_input = tk.StringVar(value="3")
        ttk.Entry(top, textvariable=self.r_input, width=10).grid(row=1, column=1, padx=(0, 14), pady=(4, 0))

        ttk.Label(top, text="Catatan", style="Card.TLabel").grid(row=0, column=2, sticky="w")
        self.note_input = tk.StringVar()
        ttk.Entry(top, textvariable=self.note_input, width=42).grid(row=1, column=2, padx=(0, 14), pady=(4, 0))

        ttk.Button(top, text="Tambah Trade", command=self.add_custom_trade).grid(row=1, column=3, padx=4)
        ttk.Button(top, text="WIN +3R", command=lambda: self.add_trade(3.0, "WIN +3R")).grid(row=1, column=4, padx=4)
        ttk.Button(top, text="LOSE -1R", command=lambda: self.add_trade(-1.0, "LOSE -1R")).grid(row=1, column=5, padx=4)

        columns = ("no", "date", "level", "lot", "r_mult", "r_value", "pnl", "balance", "note")
        self.tree = ttk.Treeview(self.tab_journal, columns=columns, show="headings")
        heads = {
            "no":"#", "date":"Tanggal", "level":"Level", "lot":"Lot", "r_mult":"Hasil R",
            "r_value":"1R", "pnl":"P/L", "balance":"Balance", "note":"Catatan"
        }
        widths = {"no":45, "date":95, "level":60, "lot":70, "r_mult":75, "r_value":80, "pnl":90, "balance":95, "note":250}
        for c in columns:
            self.tree.heading(c, text=heads[c])
            self.tree.column(c, width=widths[c], anchor="center" if c != "note" else "w")
        self.tree.pack(fill="both", expand=True, padx=14, pady=(8, 6))

        foot = ttk.Frame(self.tab_journal)
        foot.pack(fill="x", padx=14, pady=(4, 12))
        ttk.Button(foot, text="Hapus Trade Terpilih", command=self.delete_selected).pack(side="left")
        ttk.Button(foot, text="Export CSV", command=self.export_csv).pack(side="right")

    def build_levels(self):
        cols = ("level", "lot", "modal", "r", "target", "total")
        self.level_tree = ttk.Treeview(self.tab_levels, columns=cols, show="headings")
        headings = {"level":"Level", "lot":"Lot", "modal":"Modal", "r":"1R", "target":"Target +6R", "total":"Total / Level Berikutnya"}
        for c in cols:
            self.level_tree.heading(c, text=headings[c])
            self.level_tree.column(c, anchor="center", width=140)
        self.level_tree.pack(fill="both", expand=True, padx=18, pady=18)

        for x in LEVELS:
            self.level_tree.insert("", "end", values=(
                x["level"], lot_text(x["lot"]), money(x["modal"]), money(x["r"]),
                money(x["profit_target"]), money(x["total"])
            ))

    def build_settings(self):
        wrap = ttk.Frame(self.tab_settings, style="Card.TFrame", padding=22)
        wrap.pack(fill="x", padx=18, pady=18)

        ttk.Label(wrap, text="Kontrol Level", style="Card.TLabel", font=("Segoe UI Semibold", 14)).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 12))
        ttk.Button(wrap, text="Naik Level Manual", command=self.level_up_manual).grid(row=1, column=0, padx=(0, 8))
        ttk.Button(wrap, text="Turun Level Manual", command=self.level_down_manual).grid(row=1, column=1, padx=8)
        ttk.Button(wrap, text="Set Balance", command=self.set_balance_dialog).grid(row=1, column=2, padx=8)

        tools = ttk.Frame(self.tab_settings, style="Card.TFrame", padding=22)
        tools.pack(fill="x", padx=18, pady=(0, 18))
        ttk.Label(tools, text="Data", style="Card.TLabel", font=("Segoe UI Semibold", 14)).pack(anchor="w", pady=(0, 12))
        row = ttk.Frame(tools, style="Card.TFrame")
        row.pack(fill="x")
        ttk.Button(row, text="Backup JSON", command=self.backup_json).pack(side="left", padx=(0, 8))
        ttk.Button(row, text="Import JSON", command=self.import_json).pack(side="left", padx=8)
        ttk.Button(row, text="Reset Semua Data", command=self.reset_data).pack(side="right")

        info = ttk.Frame(self.tab_settings, style="Card.TFrame", padding=22)
        info.pack(fill="x", padx=18)
        ttk.Label(info, text="Penyimpanan", style="Card.TLabel", font=("Segoe UI Semibold", 14)).pack(anchor="w")
        ttk.Label(info, text=DATA_FILE, style="Card.TLabel", wraplength=850).pack(anchor="w", pady=(8, 0))

    def current_level_data(self):
        idx = max(0, min(7, int(self.data.get("current_level", 1)) - 1))
        return LEVELS[idx]

    def maybe_auto_up(self):
        if not self.data.get("auto_up", True):
            return False
        changed = False
        while self.data["current_level"] < 8:
            next_modal = LEVELS[self.data["current_level"]]["modal"]
            if self.data["balance"] >= next_modal:
                self.data["current_level"] += 1
                changed = True
            else:
                break
        return changed

    def add_custom_trade(self):
        try:
            r = float(self.r_input.get().replace(",", "."))
        except ValueError:
            messagebox.showerror("Input tidak valid", "Hasil R harus berupa angka, contoh 3 atau -1.")
            return
        self.add_trade(r, self.note_input.get().strip())

    def add_trade(self, r_mult, note=""):
        level = self.current_level_data()
        pnl = r_mult * level["r"]
        self.data["balance"] = round(float(self.data["balance"]) + pnl, 2)

        trade = {
            "date": self.date_var.get().strip() if hasattr(self, "date_var") else datetime.now().strftime("%Y-%m-%d"),
            "level": level["level"],
            "lot": level["lot"],
            "r_mult": r_mult,
            "r_value": level["r"],
            "pnl": pnl,
            "balance_after": self.data["balance"],
            "note": note
        }
        self.data["trades"].append(trade)
        leveled = self.maybe_auto_up()
        self.save_data()
        self.refresh_all()
        if leveled:
            messagebox.showinfo("Naik Level", f"Target tercapai. Sekarang masuk Level {self.data['current_level']}.")

    def delete_selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Pilih trade", "Pilih satu baris jurnal yang ingin dihapus.")
            return
        idx = int(self.tree.item(sel[0], "values")[0]) - 1
        if not messagebox.askyesno("Hapus trade", "Hapus trade terpilih dan hitung ulang balance?"):
            return
        self.data["trades"].pop(idx)
        self.recalculate_from_history()
        self.save_data()
        self.refresh_all()

    def recalculate_from_history(self):
        balance = 25.0
        level_no = 1
        rebuilt = []
        for t in self.data["trades"]:
            level = LEVELS[level_no - 1]
            pnl = float(t.get("r_mult", 0)) * level["r"]
            balance = round(balance + pnl, 2)
            nt = dict(t)
            nt.update({
                "level": level_no,
                "lot": level["lot"],
                "r_value": level["r"],
                "pnl": pnl,
                "balance_after": balance,
            })
            rebuilt.append(nt)
            while level_no < 8 and balance >= LEVELS[level_no]["modal"]:
                level_no += 1
        self.data["trades"] = rebuilt
        self.data["balance"] = balance
        self.data["current_level"] = level_no

    def refresh_all(self):
        lv = self.current_level_data()
        bal = float(self.data["balance"])
        self.v_balance.set(money(bal))
        self.v_level.set(str(lv["level"]))
        self.v_lot.set(lot_text(lv["lot"]))
        self.v_r.set(money(lv["r"]))

        if lv["level"] < 8:
            next_modal = LEVELS[lv["level"]]["modal"]
            self.v_target.set(money(next_modal))
            start = lv["modal"]
            span = max(1, next_modal - start)
            pct = max(0, min(100, ((bal - start) / span) * 100))
            self.progress["value"] = pct
            remain = max(0, next_modal - bal)
            self.v_progress.set(f"{pct:.1f}% • Sisa {money(remain)} menuju Level {lv['level'] + 1}")
        else:
            self.v_target.set(money(lv["total"]))
            self.progress["value"] = 100
            self.v_progress.set("Level maksimum tabel tercapai.")

        for item in self.tree.get_children():
            self.tree.delete(item)
        for i, t in enumerate(self.data["trades"], 1):
            self.tree.insert("", "end", values=(
                i, t.get("date",""), t.get("level",""), lot_text(float(t.get("lot",0))),
                f"{float(t.get('r_mult',0)):g}R", money(float(t.get("r_value",0))),
                money(float(t.get("pnl",0))), money(float(t.get("balance_after",0))),
                t.get("note","")
            ))

    def level_up_manual(self):
        if self.data["current_level"] >= 8:
            messagebox.showinfo("Level", "Sudah berada di Level 8.")
            return
        self.data["current_level"] += 1
        self.save_data()
        self.refresh_all()

    def level_down_manual(self):
        if self.data["current_level"] <= 1:
            messagebox.showinfo("Level", "Sudah berada di Level 1.")
            return
        self.data["current_level"] -= 1
        self.save_data()
        self.refresh_all()

    def set_balance_dialog(self):
        win = tk.Toplevel(self)
        win.title("Set Balance")
        win.geometry("330x160")
        win.resizable(False, False)
        win.transient(self)
        win.grab_set()

        ttk.Label(win, text="Balance baru ($)").pack(pady=(20, 6))
        var = tk.StringVar(value=str(self.data["balance"]))
        ent = ttk.Entry(win, textvariable=var, width=22)
        ent.pack()
        ent.focus_set()

        def apply():
            try:
                val = float(var.get().replace(",", "."))
            except ValueError:
                messagebox.showerror("Error", "Balance harus berupa angka.", parent=win)
                return
            self.data["balance"] = round(val, 2)
            self.save_data()
            self.refresh_all()
            win.destroy()

        ttk.Button(win, text="Simpan", command=apply).pack(pady=14)

    def export_csv(self):
        path = filedialog.asksaveasfilename(
            title="Export Jurnal CSV",
            defaultextension=".csv",
            filetypes=[("CSV", "*.csv")],
            initialfile="R-Level-Journal.csv"
        )
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["No","Tanggal","Level","Lot","Hasil R","1R","P/L","Balance","Catatan"])
            for i, t in enumerate(self.data["trades"], 1):
                w.writerow([i,t.get("date"),t.get("level"),t.get("lot"),t.get("r_mult"),t.get("r_value"),t.get("pnl"),t.get("balance_after"),t.get("note")])
        messagebox.showinfo("Export selesai", f"CSV tersimpan:\n{path}")

    def backup_json(self):
        path = filedialog.asksaveasfilename(
            title="Backup Data",
            defaultextension=".json",
            filetypes=[("JSON", "*.json")],
            initialfile="R-Level-Journal-Backup.json"
        )
        if not path:
            return
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
        messagebox.showinfo("Backup selesai", f"Backup tersimpan:\n{path}")

    def import_json(self):
        path = filedialog.askopenfilename(title="Import Data", filetypes=[("JSON", "*.json")])
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                d = json.load(f)
            if "balance" not in d or "trades" not in d:
                raise ValueError("Format backup tidak sesuai")
            self.data = d
            self.save_data()
            self.refresh_all()
            messagebox.showinfo("Import selesai", "Data berhasil dipulihkan.")
        except Exception as e:
            messagebox.showerror("Import gagal", str(e))

    def reset_data(self):
        if not messagebox.askyesno("Reset", "Hapus seluruh jurnal dan kembali ke Balance $25, Level 1?"):
            return
        self.data = DEFAULT_DATA.copy()
        self.save_data()
        self.refresh_all()

if __name__ == "__main__":
    app = App()
    app.mainloop()
