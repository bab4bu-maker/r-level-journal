# R-Level Journal PC

Aplikasi desktop Windows untuk jurnal trading R-Level.

Fitur:
- Dashboard balance, level, lot, 1R, target.
- Quick WIN +3R dan LOSE -1R.
- Jurnal lengkap dan export CSV.
- Tabel Level 1–8 sesuai struktur fixed compounding.
- Auto naik level saat target tercapai.
- Turun level manual agar 1 loss tidak langsung menurunkan level.
- Backup dan import JSON.
- Penyimpanan lokal di AppData.

Build:
Gunakan GitHub Actions file `.github/workflows/build-windows.yml`.
Hasil build: `R-Level-Journal.exe`.
